<?php
session_start();
// connecting to database
require 'mysqlAdapter.php';
require 'config.php';
require '../libs/Smarty.class.php';
global $config;
//var_dump($config);
$smarty = new Smarty();
$smarty->template_dir='views';
$smarty->compile_dir = 'tmp';
$db = new mysqlAdapter($config);
$db->__construct($config);

$table = '`products`';
$data = array();
foreach ($_GET['select'] as $value) {
$result = $db->select($table,$table.'.`id`='.$value);
$row = mysqli_fetch_assoc($result) ;
$data[] = $row;
//var_dump($_GET['select']); 
}
$smarty->assign('rows',$data);
//$smarty->assign('hh',$_GET['select']);
$smarty->display('add_to_card.tpl');
?>
		
	