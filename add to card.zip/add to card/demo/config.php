<?php
// configration of database
$config = array('localhost',
                'root',
                '',
                'yousef_p');