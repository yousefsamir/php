<?php
/* Smarty version 3.1.34-dev-7, created on 2020-01-30 23:22:38
  from 'C:\xampp\htdocs\PHP test\smarty-master\demo\templates\header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e33572ed512c1_73003401',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '423913d7a666e57b90894da93e3dc09c7c2a37e7' => 
    array (
      0 => 'C:\\xampp\\htdocs\\PHP test\\smarty-master\\demo\\templates\\header.tpl',
      1 => 1580137714,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e33572ed512c1_73003401 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '13371381995e33572ed4fb98_28890307';
?>
<HTML>
<HEAD>
<TITLE><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
 - <?php echo '/*%%SmartyNocache:13371381995e33572ed4fb98_28890307%%*/<?php echo $_smarty_tpl->tpl_vars[\'Name\']->value;?>
/*/%%SmartyNocache:13371381995e33572ed4fb98_28890307%%*/';?>
</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">
<?php }
}
