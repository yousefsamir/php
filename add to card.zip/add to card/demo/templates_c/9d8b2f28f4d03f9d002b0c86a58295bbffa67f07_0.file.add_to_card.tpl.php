<?php
/* Smarty version 3.1.34-dev-7, created on 2020-01-31 00:54:03
  from 'C:\xampp\htdocs\PHP test\smarty-master\demo\views\add_to_card.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e336c9be00ca2_31498920',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9d8b2f28f4d03f9d002b0c86a58295bbffa67f07' => 
    array (
      0 => 'C:\\xampp\\htdocs\\PHP test\\smarty-master\\demo\\views\\add_to_card.tpl',
      1 => 1580428433,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e336c9be00ca2_31498920 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h2> chosen products </h2>
	<table style=" text-align: center; border: 4px;">
		<thead>
			<th> ID ||</th>
			<th> Name ||</th>
			<th> Quantity </th>
		</thead>
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['rows']->value, 'row');
$_smarty_tpl->tpl_vars['row']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['row']->value) {
$_smarty_tpl->tpl_vars['row']->do_else = false;
?>
		<tbody>
			<tr>
				<td> <?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
</td>
                <td> <?php echo $_smarty_tpl->tpl_vars['row']->value['name'];?>
 </td>
                <td> <?php echo $_smarty_tpl->tpl_vars['row']->value['email'];?>
 </td>
                <br>
		    </tr>
		</tbody>
		 <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		</table>
</body>
</html><?php }
}
