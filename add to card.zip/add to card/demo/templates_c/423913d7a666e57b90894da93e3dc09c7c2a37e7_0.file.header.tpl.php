<?php
/* Smarty version 3.1.34-dev-7, created on 2020-01-31 00:01:08
  from 'C:\xampp\htdocs\PHP test\smarty-master\demo\templates\header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e336034eedce4_36567917',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '423913d7a666e57b90894da93e3dc09c7c2a37e7' => 
    array (
      0 => 'C:\\xampp\\htdocs\\PHP test\\smarty-master\\demo\\templates\\header.tpl',
      1 => 1580423694,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e336034eedce4_36567917 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<!--<h2> list all product </h2>
	<form method="GET" action="add_to_card.php">
		<input type="text" name="search" placeholder="search by name">
		<input type="submit" value="search">
	</form>-->
	<table style=" text-align: center; border: 4px;">
		<thead>
			<th> ID ||</th>
			<th> Name ||</th>
			<th> Quantity </th>
			<th> Choose </th>
		</thead>
		<form method="GET" action="add_to_card.php">
		<tbody>
			<tr>
				<td> <?php echo '<?=';?>
$row['id'] <?php echo '?>';?>
</td>
				<td> <?php echo '<?=';?>
$row['name']."  " <?php echo '?>';?>
</td>
				<td> <?php echo '<?=';?>
$row['email']."  " <?php echo '?>';?>
</td><br>
				<td>
					<input type="checkbox" name="select[]" id="select"
					 value="<?php echo '<?=';?>
$row['id'];<?php echo '?>';?>
">
				</td>


		    </tr>
		</tbody>
		</table>
	
		<input type="submit" name="choose" value="add_to_card">
	
	</form>

<?php }
}
