<?php
/* Smarty version 3.1.34-dev-7, created on 2020-01-30 23:22:38
  from 'C:\xampp\htdocs\PHP test\smarty-master\demo\templates\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e33572ed654a8_04590615',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '73c6fe0fb676b4299b20b5e275bfcc4f90960cc1' => 
    array (
      0 => 'C:\\xampp\\htdocs\\PHP test\\smarty-master\\demo\\templates\\footer.tpl',
      1 => 1580137714,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e33572ed654a8_04590615 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '545864715e33572ed64670_95600656';
?>
</BODY>
</HTML>
<?php }
}
