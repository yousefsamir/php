<?php
/* Smarty version 3.1.34-dev-7, created on 2020-01-31 00:53:35
  from 'C:\xampp\htdocs\PHP test\smarty-master\demo\views\list_product.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e336c7fef09a8_85917854',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '099793420c3d714f56eb6960a8a2bc87fd396f79' => 
    array (
      0 => 'C:\\xampp\\htdocs\\PHP test\\smarty-master\\demo\\views\\list_product.tpl',
      1 => 1580428414,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e336c7fef09a8_85917854 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
    <!--<h2> list all product </h2>
    <form method="GET" action="add_to_card.php">
        <input type="text" name="search" placeholder="search by name">
        <input type="submit" value="search">
    </form>-->
    <table style=" text-align: center; border: 4px;">
        <thead>
            <th> ID ||</th>
            <th> Name ||</th>
            <th> Quantity </th>
            <th> Choose </th>
        </thead>
        <form method="GET" action="add_to_card.php">
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['rows']->value, 'row');
$_smarty_tpl->tpl_vars['row']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['row']->value) {
$_smarty_tpl->tpl_vars['row']->do_else = false;
?>
        <tbody>
            <tr>
                <td> <?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
</td>
                <td> <?php echo $_smarty_tpl->tpl_vars['row']->value['name'];?>
 </td>
                <td> <?php echo $_smarty_tpl->tpl_vars['row']->value['email'];?>
 </td>
                <br>
                <td>
                    <input type="checkbox" name="select[]" id="select"
                     value="<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
">
                </td>


            </tr>
        </tbody>
        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </table>
    
        <input type="submit" name="choose" value="add_to_card">
    
    </form><?php }
}
