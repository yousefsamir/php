<?php /* Smarty version 3.1.34-dev-7, created on 2020-01-30 23:22:38
         compiled from 'C:\xampp\htdocs\PHP test\smarty-master\demo\configs\test.conf' */ ?>
<?php
/* Smarty version 3.1.34-dev-7, created on 2020-01-30 23:22:38
  from 'C:\xampp\htdocs\PHP test\smarty-master\demo\configs\test.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e33572ed3e2a3_94271314',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4899997ec7f7e4a23e7bca70f97e3324c3095899' => 
    array (
      0 => 'C:\\xampp\\htdocs\\PHP test\\smarty-master\\demo\\configs\\test.conf',
      1 => 1580137714,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e33572ed3e2a3_94271314 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'setup' => 
    array (
      'vars' => 
      array (
        'bold' => true,
      ),
    ),
  ),
  'vars' => 
  array (
    'title' => 'Welcome to Smarty!',
    'cutoff_size' => 40,
  ),
));
}
}
