<?php
session_start();
// connecting to database
require 'mysqlAdapter.php';
require 'config.php';
require '../libs/Smarty.class.php';
$smarty = new Smarty();
$smarty->template_dir ='views';
$smarty->compile_dir ='tmp';
global $config;
//var_dump($config);
$db = new mysqlAdapter($config);
$table = '`products`';

$result = $db->select($table);
$data = array();
while ( $row = mysqli_fetch_assoc($result)) 
{
	$data[] = $row;
		
	$key = 'user_'.$row['id'];
    $_SESSION[$key] = $row;
}
$smarty->assign('rows',$data);
$smarty->display('list_product.tpl');
		
	