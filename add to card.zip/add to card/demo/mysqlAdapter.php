<?php

class mysqlAdapter 
{
	protected $_config = array();
	protected $_link;
	protected $_result;
	
	public function __construct(array $config)
	{
		if(sizeof($config) !== 4)
			throw new InvalidArgumentException('Invalid connection parameter');
		$this->_config = $config;

	}
	public function connect()
	{
		if ($this->_link == null) {
			list($host , $user , $password , $DB) = $this->_config;
			$this->_link = mysqli_connect($host,$user,$password,$DB);
			if (!$this->_link) {
				throw new RunTimeException('error connecting to database :')
				.mysqli_connect_error();
			}
			unset($host , $user , $password , $DB);
		}
		return $this->_link;
	}
	public function query($query)
	{
		if (!is_string($query) || empty($query)) {
			throw new Exception("Error Processing Request");
			}
		$this->connect();
		$this->_result = mysqli_query($this->_link ,$query);
		if (!$this->_result) {
			throw new RuntimeException("Error Processing query").$query;
			
		}
		return $this->_result;

	}
	public function select($table ,$where='' ,$col ='*',
		                         $offset=null ,$limit=null ,$order='')
	{
		$query = 'SELECT '.$col.' FROM'.$table
		.(($where)?'WHERE'.$where:'')
		.(($limit)?'LIMIT'.$limit:'')
		.(($offset&&$limit)?'OFFSET'.$offset:'')
		.(($order)?'ORDER BY'.$order:'');
		$this->query($query);
		return $this->_result;

	}
	public function update($table ,array $values ,$where)
	{
		foreach ($values as $field => $value) {
			$set[]=$field.'='.$this->quatevalue($value);
		}
		$set = implode(',', $set);
		$query = 'UPDATE'.$table.'SET'.$set
		.(($where)?'WHERE'.$where:'');

		$this->query($query);
		return getAffectedRows();
	}
	public function delete($table ,$where)
	{
		$query = 'DELETE FROM '.$table
		.(($where)?'WHERE'.$where:'');
		$this->query($query);
		return getAffectedRows();
	}
	public function insert($table ,array $values)
	{
		$fiels = implode(',' ,array_keys($values));
		$values = implode(',', array_map(array($this ,'quatevalue'), array_values($values)));
		$query = 'INSERT INTO'.$table.'('.$fiels.') VALUES ('.$values.')';
		$this->query($query);
		return getInsertId();
	}
	public function quatevalue($value='')
	{
		$this->connect();
		if ($value ==null) {
			$value = 'NULL';
		}
		elseif (!is_numeric($value)) {
			$value = "'".mysqli_escape_string($this->$_link ,$value)."'";
		}
		return $value;
	}
	public function getInsertId()
	{
		return $this->_link!==null
		       ?mysqli_num_rows($this->_result):0;
	}
	public function getAffectedRows()
	{
		return $this->_link!==null
		?mysqli_affected_rows($this->_result):0;
	}
	public function disconnect()
	{
		if ($this->_link === null) {
			return false;
		}
		mysqli_close($this->_link);
		$this->_link = null;
		return true;
	}
	public function __destruct()
	{
		$this->disconnect();
	}

}