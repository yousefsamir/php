<?php
session_start();
require "mysqlAdapter.php";
require "config.php";
//require '../libs/Smarty.class.php';
$user = new mysqlAdapter($config);
$table = '`clients`';
$where = "`clients`.`email` LIKE '%".$_POST['email']."%'";
$result = $user->select($table, $where);
$error = array();
if ($result) {
	$row = mysqli_fetch_assoc($result);
	var_dump($row);
	if (isset($_POST['password']) &&
		  sha1($_POST['password']) === $row['password']) {
		//echo "string11";
		header("Location: list.php");
	    $_SESSION['user_mail'] = $row['email'];
	}
    elseif ($row === NULL) {
	    $error[] = "email";
	    //echo "\n string2";
	    header("Location: loginform.php?error=".
		implode(',', $error));
}
	else
	{
		$error[]="password";
		//echo "string1";
		header("Location: loginform.php?error=".
		implode(',', $error));
	}
}

mysqli_close($connect);