<?php
require "mysqlAdapter.php";
require "config.php";
require '../libs/Smarty.class.php';
$user = new mysqlAdapter($config);
$smarty = new Smarty;
$smarty->template_dir ='views';
$table = '`clients`';
$id = filter_input(INPUT_GET,'id',FILTER_SANITIZE_NUMBER_INT);
//var_dump($id);
$where = " `clients`.`id`=".$id;
$result = $user->select($table, $where);
$rows = mysqli_fetch_assoc($result);
//var_dump($result);
$smarty->assign('error',$rows);
mysqli_free_result($result);
$smarty->display('edit.tpl');