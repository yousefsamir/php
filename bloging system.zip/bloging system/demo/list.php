<?php
session_start();
require "mysqlAdapter.php";
require "config.php";
require '../libs/Smarty.class.php';
$user = new mysqlAdapter($config);
/*if( !isset($_SESSION['user_mail']))
{
	header("Location: loginform.php");
	exit;
}*/
$smarty = new Smarty();
$table = '`clients`';
$smarty->template_dir ='views';
$where = "";
if (isset($_GET['search'])) {
	$search = filter_var($_GET['search'],  
		      FILTER_SANITIZE_STRING);
	$where ="`clients`.`name` LIKE '%".$search."%' OR `clients`.`email` LIKE '%".$search."%'";
}
$result = $user->select($table, $where);
$users = array();
foreach ($result as $row) {
	$users[] = $row;
}
mysqli_free_result($result);
$smarty->assign('users',$users);
$smarty->display('list.tpl');
session_destroy();