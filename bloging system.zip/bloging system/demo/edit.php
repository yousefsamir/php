<?php
require "mysqlAdapter.php";
require "config.php";
//require '../libs/Smarty.class.php';
$user = new mysqlAdapter($config);
$error_field = array();
$table = '`clients`';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	if (!(isset($_POST['name'])&& !empty($_POST['name']))) {
	$error_field['name'] = 'name not entered';
	}
	if (!(isset($_POST['email'])&& filter_input(INPUT_POST, 
		'email',FILTER_VALIDATE_EMAIL))) {
		$error_field['email'] = 'not valid email';
	}
	if (!(isset($_POST['password'])&& strlen($_POST['password'])>5)) {
		$error_field['password'] = 'short password or not entered';
	}
}


//$smarty->assign("error",$error_field);
if (!$error_field) {
	$id = filter_input(INPUT_POST,'id', FILTER_SANITIZE_NUMBER_INT);
   $name = mysqli_escape_string($connect,$_POST['name']);
   $email = mysqli_escape_string($connect,$_POST['email']);
   $password = mysqli_escape_string($connect,$_POST['password']);
   (isset($_POST['admin']))?$admin=1:$admin=0;
   $avatar = '';
   $uploads_dir = $_SERVER['DOCUMENT_ROOT']."/uploads";
   if ($_FILES["avatar"]['error'] == UPLOAD_ERR_OK) {
		$tmp_name = $_FILES["avatar"]["tmp_name"];
		$avatar = basename($_FILES["avatar"]["name"]);
		move_uploaded_file($tmp_name, "$uploads_dir/$name$avatar");
	}
}

$values = array('`name`'=>$_POST['name'],
  '`email`'=>$_POST['email'],'`password`'=>sha1($_POST['password'])
  ,'`admin`'=>$admin,'`avatar`'=>$uploads_dir."/"
  .$name.$avatar); 
$where ='`id`= '.$id;
$user->update($table,$values,$where);

	echo "string";
	header("Location: list.php");
    exit;

//mysql_free_result($result);
//mysqli_close($connect);