<?php
session_start();
require '../libs/Smarty.class.php';
$smarty = new Smarty;
$smarty->template_dir ='views';
if (!(isset($_POST['name'])&& !empty($_POST['name']))) {
	$error_field[] = 'name';
}
if (!(isset($_POST['email'])&& filter_input(INPUT_POST, 
	'email',FILTER_VALIDATE_EMAIL))) {
	$error_field[] = 'email';
}
if (!(isset($_POST['password'])&& strlen($_POST['password'])>5)) {
	$error_field[] = 'password';
}

//$smarty->assign("error",$error_field);
if (isset($error_field)) {
	
	header("Location: form.php?error_field="
		.implode(',', $error_field));
	exit;
}
$connect = mysqli_connect('localhost','root','','yousef_p');
if (!$connect) {
	echo mysqli_connect_error();
	exit;
}
//$smarty->display('register.tpl');
$name = mysqli_escape_string($connect,$_POST['name']);
$email = mysqli_escape_string($connect,$_POST['email']);
$password = mysqli_escape_string($connect,$_POST['password']);
$avatar = '';
$uploads_dir = $_SERVER['DOCUMENT_ROOT']."/uploads";
if ($_FILES["avatar"]['error'] == UPLOAD_ERR_OK) {
	$tmp_name = $_FILES["avatar"]["tmp_name"];
	$avatar = basename($_FILES["avatar"]["name"]);
	move_uploaded_file($tmp_name, "$uploads_dir/$name$avatar");
}
else
{
	$avatar = "noimage.png";
}
//$admin=0;
(isset($_POST['admin']))?$admin=1:$admin=0;
//var_dump($_POST['admin']);
$query = "INSERT INTO `clients` (`name`,`email`,
         `password`,`admin`,`avatar`) VALUES ('".$_POST['name']."',
         '".$_POST['email']."','".sha1($_POST['password']).
         "','".$admin."','".$uploads_dir."/".$name.$avatar."')";
$result = mysqli_query($connect ,$query);
if (!$result) {
	echo mysqli_connect_error();
}
//var_dump(expression)
$_SESSION['user_mail'] = $_POST['email'];
//$_SESSION['user_id'] = $_POST['id'];
//echo $uploads_dir."/".$name.$avatar;
header("Location: list.php");
//mysql_free_result($result);
if (mysqli_close($connect)) {
	
    exit;
}

