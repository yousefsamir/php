<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-05 00:07:45
  from 'C:\xampp\htdocs\bloging system\smarty-master\demo\views\form.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e39f941e6fdb3_40163926',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f86925270728c31b842f32e9f93c6f46e9d97220' => 
    array (
      0 => 'C:\\xampp\\htdocs\\bloging system\\smarty-master\\demo\\views\\form.tpl',
      1 => 1580857651,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e39f941e6fdb3_40163926 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
<style>
input[type=text],input[type=email],
input[type=password],input[type=radio] {
    position: relative;
    left: 400px;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}


input[type=submit] {
    position: relative;
    left: 400px;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}

div#body {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 40px;
}
input[type=button] {
    display: inline;
    position: relative;
    text-align: right;
    top: -5px;
    
}
div#top_right
{
    position: absolute;
    top: 10px;
    right: 5px;
}
</style>
<body>
<div id="head">
    <h3 style="text-align: center;">register form</h3>
    <div id="top_right">
        <input type="button" name="register" value="register">
        <input type="button" name="login" value="login">        
    </div>
</div>

<div id="body">
  <form method="POST">
    <label for="name" style="position: relative;left: 400px;">
     Name</label><br>
    <input type="text" id="name" name="name"><br>
    <label for="name" style="position: relative;left: 400px;"> Email</label><br>
    <input type="email" id="email" name="email"><br>
    <label for="password" style="position: relative;left: 400px;">password</label><br>
    <input type="password" id="password" name="password"><br>
    <label for="gender" style="position: relative;left: 400px;"> Gender:</label>
    <input type="radio" name="gender" value="male">
    <label for="gender" style="position: relative;left: 400px;"> male</label>
    <input type="radio" name="gender" value="female">
    <label for="gender" style="position: relative;left: 400px;"> male</label><br>
    <input type="submit" name="submit" value="register">
  </form>
</div>

</body>

<!-- Mirrored from www.w3schools.com/css/tryit.asp?filename=trycss_forms by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 13 Mar 2016 11:04:37 GMT -->
</html>
<?php }
}
