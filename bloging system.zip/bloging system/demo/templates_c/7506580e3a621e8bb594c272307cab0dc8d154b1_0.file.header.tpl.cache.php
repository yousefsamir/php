<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-03 21:10:35
  from 'C:\xampp\htdocs\bloging system\smarty-master\demo\templates\header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e387e3b02d0d8_82475021',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '7506580e3a621e8bb594c272307cab0dc8d154b1' => 
    array (
      0 => 'C:\\xampp\\htdocs\\bloging system\\smarty-master\\demo\\templates\\header.tpl',
      1 => 1580137714,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e387e3b02d0d8_82475021 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '7938924975e387e3b029ff3_26808682';
?>
<HTML>
<HEAD>
<TITLE><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
 - <?php echo '/*%%SmartyNocache:7938924975e387e3b029ff3_26808682%%*/<?php echo $_smarty_tpl->tpl_vars[\'Name\']->value;?>
/*/%%SmartyNocache:7938924975e387e3b029ff3_26808682%%*/';?>
</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">
<?php }
}
