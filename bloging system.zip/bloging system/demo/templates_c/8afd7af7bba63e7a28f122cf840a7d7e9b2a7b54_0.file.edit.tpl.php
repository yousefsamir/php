<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-11 06:26:20
  from 'C:\xampp\htdocs\bloging system\smarty-master\demo\views\edit.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e423afc896376_83366149',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8afd7af7bba63e7a28f122cf840a7d7e9b2a7b54' => 
    array (
      0 => 'C:\\xampp\\htdocs\\bloging system\\smarty-master\\demo\\views\\edit.tpl',
      1 => 1581398777,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e423afc896376_83366149 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
<style>
input[type=text],input[type=email],
input[type=password],input[type=radio],
input[type=file]{
    position: relative;
    left: 400px;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}


input[type=submit] {
    position: relative;
    left: 400px;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}

div#body {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 40px;
}
input[type=button] {
    display: inline;
    position: relative;
    text-align: right;
    top: -5px;
    
}
div#top_right
{
    position: absolute;
    top: 10px;
    right: 5px;
}
</style>
<body>

<div id="body">
  <form method="POST" action="edit.php" 
        enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?php echo $_smarty_tpl->tpl_vars['error']->value['id'];?>
">
    <label for="name" style="position: relative;left: 400px;">
     Name</label><br>
    <input type="text" id="name" name="name" 
    value=" <?php echo $_smarty_tpl->tpl_vars['error']->value['name'];?>
" ><br>
    <label for="name" style="position: relative;left: 400px;"> Email</label><br>
    <input type="email" id="email" name="email" 
    value="<?php echo $_smarty_tpl->tpl_vars['error']->value['email'];?>
"><br>
    <label for="password" style="position: relative;left: 400px;">password</label><br>
    <input type="password" id="password" name="password" 
    value="<?php echo $_smarty_tpl->tpl_vars['error']->value['password'];?>
"><br>
    <label for="gender" style="position: relative;left: 400px;"> Admin:</label>
    <input type="radio" name="admin"
    <?php echo $_smarty_tpl->tpl_vars['error']->value['admin'] ? 'checked' : '';?>
><br>
    <label for="avatar" style="position: relative;left: 400px;"> image:</label>
    <input type="file" name="avatar" value="<?php echo $_smarty_tpl->tpl_vars['error']->value['password'];?>
"><br>
    <input type="submit" name="submit" value="update">
  </form>
</div>

</body>

<!-- Mirrored from www.w3schools.com/css/tryit.asp?filename=trycss_forms by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 13 Mar 2016 11:04:37 GMT -->
</html>
<?php }
}
