<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-07 17:34:44
  from 'C:\xampp\htdocs\bloging system\smarty-master\demo\views\list.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e3d91a4260818_74961533',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a77b9b02c186ee5752b96a27251d4460d2610ff3' => 
    array (
      0 => 'C:\\xampp\\htdocs\\bloging system\\smarty-master\\demo\\views\\list.tpl',
      1 => 1581093280,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e3d91a4260818_74961533 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h2 style="position: absolute;left: 300px;"> all users </h2>
	<form method="GET"
	 style=" text-align: center; border: 4px;
	 position: absolute; left: 300px;">
		<input type="text" name="search" placeholder="search by name or email">
		<input type="submit" name="submit" value="search">
	</form>
	<table style=" text-align: center; border: 4px;
	 position: absolute; left: 300px;">
		<thead>
			<th> ID ||</th>
			<th> Name ||</th>
			<th> Email </th>
			<th> Admin </th>
			<th> Image </th>
			<th> Action </th>
		</thead>
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['users']->value, 'row');
$_smarty_tpl->tpl_vars['row']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['row']->value) {
$_smarty_tpl->tpl_vars['row']->do_else = false;
?>
		<tbody>
			<tr>
				<td> <?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
</td>
                <td> <?php echo $_smarty_tpl->tpl_vars['row']->value['name'];?>
 </td>
                <td> <?php echo $_smarty_tpl->tpl_vars['row']->value['email'];?>
 </td>
                <td> <?php echo $_smarty_tpl->tpl_vars['row']->value['admin'] ? 'yes' : 'no';?>
</td>
                <td>

                	 <?php if (($_smarty_tpl->tpl_vars['row']->value['avatar'])) {?>

                	 <img 
                	 src="../../uploads/<?php echo $_smarty_tpl->tpl_vars['row']->value['name'][$_smarty_tpl->tpl_vars['row']->value]['avatar'];?>
" style="height: 100px;width: 100px;">
                	 <?php } else { ?>
                	 no image
                	 <?php }?>
                </td>
                <td>
                	<a href="editform.php?id=<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
">edit</a>||
                	<a href="delete.php?id=<?php echo $_smarty_tpl->tpl_vars['row']->value['id'];?>
">delete</a>
                </td>
                <br>
		    </tr>
		</tbody>
		 <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		 <tfoot>
		 	<tr>
		 		<td>
		 			<a href="form.php"><input type="button" name="add" value="add user"></a>
		 		</td>	
		 	</tr>
		 </tfoot>
		</table>
</body>
</html><?php }
}
