<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-06 03:04:19
  from 'C:\xampp\htdocs\bloging system\smarty-master\demo\edit.php' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e3b7423a8d403_44666256',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '78b6b496bf0b5e42271f26b60070a7c2db162eb8' => 
    array (
      0 => 'C:\\xampp\\htdocs\\bloging system\\smarty-master\\demo\\edit.php',
      1 => 1580954477,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e3b7423a8d403_44666256 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?php

';?>
if (!(isset($_POST['name'])&& !empty($_POST['name']))) {
	$error_field['name'] = 'name not entered';
}
if (!(isset($_POST['email'])&& filter_input(INPUT_POST, 
	'email',FILTER_VALIDATE_EMAIL))) {
	$error_field['email'] = 'not valid email';
}
if (!(isset($_POST['password'])&& strlen($_POST['password'])>5)) {
	$error_field['password'] = 'short password or not entered';
}

//$smarty->assign("error",$error_field);
if (isset($error_field)) {
	
	header("Location: editform.php?error_field="
		.implode(',', $error_field));
	exit;
}

//$smarty->display('register.tpl');
$name = mysqli_escape_string($connect,$_POST['name']);
$email = mysqli_escape_string($connect,$_POST['email']);
$password = mysqli_escape_string($connect,$_POST['password']);
//$admin=0;
(isset($_POST['admin']))?$admin=1:$admin=0;
//var_dump($_POST['admin']);
$query = "INSERT INTO `clients` (`name`,`email`,
         `password`,`admin`) VALUES ('".$_POST['name']."',
         '".$_POST['email']."','".sha1($_POST['password']).
         "','".$admin."' )";
$result = mysqli_query($connect ,$query);
if (!$result) {
	echo mysqli_connect_error();
}
header("Location: list.php");
//mysql_free_result($result);
if (mysqli_close($connect)) {
	
    exit;
}<?php }
}
