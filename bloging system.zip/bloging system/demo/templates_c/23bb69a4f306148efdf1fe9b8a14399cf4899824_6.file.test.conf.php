<?php /* Smarty version 3.1.34-dev-7, created on 2020-02-03 21:10:35
         compiled from 'C:\xampp\htdocs\bloging system\smarty-master\demo\configs\test.conf' */ ?>
<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-03 21:10:35
  from 'C:\xampp\htdocs\bloging system\smarty-master\demo\configs\test.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e387e3b011456_78895307',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '23bb69a4f306148efdf1fe9b8a14399cf4899824' => 
    array (
      0 => 'C:\\xampp\\htdocs\\bloging system\\smarty-master\\demo\\configs\\test.conf',
      1 => 1580137714,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e387e3b011456_78895307 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'setup' => 
    array (
      'vars' => 
      array (
        'bold' => true,
      ),
    ),
  ),
  'vars' => 
  array (
    'title' => 'Welcome to Smarty!',
    'cutoff_size' => 40,
  ),
));
}
}
