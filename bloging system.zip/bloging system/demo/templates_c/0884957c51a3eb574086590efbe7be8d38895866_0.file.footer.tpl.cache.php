<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-03 21:10:35
  from 'C:\xampp\htdocs\bloging system\smarty-master\demo\templates\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e387e3b070be3_50501299',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0884957c51a3eb574086590efbe7be8d38895866' => 
    array (
      0 => 'C:\\xampp\\htdocs\\bloging system\\smarty-master\\demo\\templates\\footer.tpl',
      1 => 1580137714,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e387e3b070be3_50501299 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '13614426855e387e3b06ed38_26510439';
?>
</BODY>
</HTML>
<?php }
}
