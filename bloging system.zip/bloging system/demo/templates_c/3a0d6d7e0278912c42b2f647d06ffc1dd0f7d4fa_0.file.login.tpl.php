<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-11 05:45:28
  from 'C:\xampp\htdocs\bloging system\smarty-master\demo\views\login.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e4231686d3581_98338547',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3a0d6d7e0278912c42b2f647d06ffc1dd0f7d4fa' => 
    array (
      0 => 'C:\\xampp\\htdocs\\bloging system\\smarty-master\\demo\\views\\login.tpl',
      1 => 1581396315,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e4231686d3581_98338547 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
<style>
input[type=email],input[type=password] {
    position: relative;
    left: 400px;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}


input[type=submit] {
    position: relative;
    left: 400px;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}

div#body {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 40px;
}
div#top_right
{
    position: absolute;
    top: 10px;
    right: 20px;
}
</style>
<body>
<div id="top_right">
        <a href="register.php">
            <input type="button" name="register" value="register"> 
        </a>
               
</div>
<div id="body">
  <form method="POST" action="login.php">
    <label for="name" style="position: relative;left: 400px;"> Email</label><br>
    <input type="email" id="email" name="email"><br>
    <?php if (in_array('email',$_smarty_tpl->tpl_vars['error']->value)) {?>
    <p style="position: relative;left: 400px;">email not found</p>
    <?php }?>
    <label for="password" style="position: relative;left: 400px;">password</label><br>
    <input type="password" id="password" name="password"><br>
    <?php if (in_array('password',$_smarty_tpl->tpl_vars['error']->value)) {?>
    <p style="position: relative;left: 400px;">incorrect password</p>
    <?php }?>
    <input type="submit" name="submit" value="login">
  </form>
</div>

</body>

</html>
<?php }
}
