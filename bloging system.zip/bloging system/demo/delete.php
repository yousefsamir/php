<?php
require "mysqlAdapter.php";
require "config.php";
//require '../libs/Smarty.class.php';
$user = new mysqlAdapter($config);
$table = '`clients`';
$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
$where = "`id`=".$id;
$user->delete($table ,$where);
header("Location: list.php");
exit;