<?php
require "../mysqlAdapter.php";
require "../config.php";
$user = new mysqlAdapter($config);
$val = array('`name`'=>'ahmedhr','`email`'=>'inchr@example.com',
	'`password`'=>'1234567');
 $user->update('`clients`',$val,'`id`= 20');

?>