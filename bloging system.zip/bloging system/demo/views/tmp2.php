<?php
// Start the session
session_start();

// Set session variables
if (isset($_SESSION["favcolor"])) {
	echo "Session are ok.";
}

?>