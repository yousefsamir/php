<?php
require '../libs/Smarty.class.php';
$smarty = new Smarty;
$smarty->template_dir ='views';
$error = array();
if (isset($_GET['error_field'])) {
	$error = explode(',',$_GET['error_field']);
}


//var_dump($error);
$smarty->assign('error',$error);
$smarty->display('register.tpl');