<?php
require '../libs/Smarty.class.php';
$smarty = new Smarty();
$smarty->template_dir ='views';
$error = array();
if(isset($_GET['error']))
{
	$error = explode(',', $_GET['error']);
}
$smarty->assign('error',$error);
$smarty->display('login.tpl');
